package edu.tcu.cs.superfrogserver.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.tcu.cs.superfrogserver.domain.Client;
import edu.tcu.cs.superfrogserver.domain.Result;
import edu.tcu.cs.superfrogserver.domain.StatusCode;
import edu.tcu.cs.superfrogserver.service.ClientService;

@RestController
@RequestMapping("/clients")
public class ClientController {
    private ClientService service;

    public ClientController(ClientService service){this.service = service;}

    @GetMapping
    public Result findAll(){
        return new Result(true, StatusCode.SUCCESS, "Find All Success", service.findAll());
    }    

    @GetMapping("/{clientId}")
    public Result findById(@PathVariable Integer clientId){
        return new Result(true, StatusCode.SUCCESS, "Find One Success", service.findById(clientId));
    }

    @PostMapping
    public Result save(@RequestBody Client client){
        service.save(client);
        return new Result(true, StatusCode.SUCCESS, "Save Success");
    }

    @PutMapping("/{clientId}")
    public Result update(@PathVariable Integer clientId, @RequestBody Client client){
        service.update(clientId, client);
        return new Result(true, StatusCode.SUCCESS, "Update Success");
    }

    @DeleteMapping("/{clientId}")
    public Result deleteById(@PathVariable Integer clientId){
        Client c = (Client) service.findById(clientId);
        c.setIsActive(false);
        service.update(clientId, c);
        return new Result(true, StatusCode.SUCCESS, "Delete Success");
    }

    //TODO move to frogcontroller
    // @PutMapping("/{clientId}/{eventId}")
    // public Result assignEvent(@PathVariable Integer clientId, @PathVariable String eventId){
    //     service.assign(clientId, eventId);
    //     return new Result(true, StatusCode.SUCCESS, "event Assignment Success");
    // }


    
}
