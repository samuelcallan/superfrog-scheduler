package edu.tcu.cs.superfrogserver.domain;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Event implements Serializable{
    @Id
    //TODO add generatedValue here
    private int eventId;
    private String name;
    private int clientId;
    private String location;
    private String date;
    private String description;
    private String frog;
    private String status;
    
    public Event(){

    }


    public int getEventId() {
        return this.eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getClientId() {
        return this.clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public String getLocation() {
        return this.location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDate() {
        return this.date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFrog() {
        return this.frog;
    }

    public void setFrog(String frog) {
        this.frog = frog;
    }

    public String isStatus() {
        return this.status;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    
    

    
}
