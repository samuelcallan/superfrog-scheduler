package edu.tcu.cs.superfrogserver.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.tcu.cs.superfrogserver.domain.Event;
import edu.tcu.cs.superfrogserver.domain.Result;
import edu.tcu.cs.superfrogserver.domain.StatusCode;
import edu.tcu.cs.superfrogserver.service.EventService;

@RestController
@RequestMapping("/artifacts")
public class EventController {

    private EventService service;

    //see ArtifactService for why this is needed
    public EventController(EventService service) {
        this.service = service;
    }

    @GetMapping
    public Result findAll(){
        List<Event> all = service.findAll();
        //wrap service result into Result object
        Result result = new Result(true, StatusCode.SUCCESS, "Find all Success", all);
        //calling return performs a JSON serialize in the background
        return result;
    }

    @GetMapping("/{eventId}")
    public Result findById(@PathVariable int eventId){
        return new Result(true, StatusCode.SUCCESS, "Find One Success", service.findById(eventId));
    }

    @PostMapping
    public Result save(@RequestBody Event newevent){
        service.save(newevent);
        return new Result(true, StatusCode.SUCCESS, "Save Success");
    }

    @PutMapping("/{eventId}")
    public Result update(@PathVariable int eventId, @RequestBody Event updatedevent){
        service.update(eventId, updatedevent);
        return new Result(true, StatusCode.SUCCESS, "Update Success");
    }

    @DeleteMapping("/{eventId}")
    public Result delete(@PathVariable int eventId){
        //eventService.delete(eventId);
        Event e =  (Event) service.findById(eventId);
        e.setStatus("REJECTED");
        service.update(eventId, e);
        return new Result(true, StatusCode.SUCCESS, "Delete Success");
    }

    
}
