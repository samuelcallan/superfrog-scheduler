package edu.tcu.cs.superfrogserver.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.tcu.cs.superfrogserver.domain.Client;

public interface ClientDao extends JpaRepository<Client, Integer>{
    
}
