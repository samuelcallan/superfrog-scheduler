package edu.tcu.cs.superfrogserver.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.tcu.cs.superfrogserver.domain.User;

public interface UserDao extends JpaRepository<User, Integer>{
}
