package edu.tcu.cs.superfrogserver.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter{
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        //the order of the ant pattern definitions matters a lot
        http.authorizeRequests()
            .antMatchers("/h2-console").permitAll()
            .antMatchers("/artifacts/**").permitAll()
            .antMatchers("/wizards/**").permitAll()
            .antMatchers("/users/login").permitAll()
            .antMatchers("/users").authenticated()
            .antMatchers(HttpMethod.DELETE, "/users/**").hasAuthority("admin")
            .and().formLogin().loginProcessingUrl("/users/login");

        http.csrf().disable();
        //for h2 console
        http.headers().frameOptions().disable();
    }
    
}
