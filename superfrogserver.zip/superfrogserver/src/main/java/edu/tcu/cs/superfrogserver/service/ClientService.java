package edu.tcu.cs.superfrogserver.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.tcu.cs.superfrogserver.dao.ClientDao;
import edu.tcu.cs.superfrogserver.domain.Client;

@Service
@Transactional
public class ClientService {

    private ClientDao dao;


    public ClientService(ClientDao dao) {
        this.dao = dao;
    }


    public ClientDao getDao() {
        return this.dao;
    }

    public void setDao(ClientDao dao) {
        this.dao = dao;
    }


    public Object findAll() {
        return null;
    }


    public Object findById(Integer clientId) {
        return null;
    }


    public void save(Client client) {
    }


    public void update(Integer clientId, Client client) {
    }



}