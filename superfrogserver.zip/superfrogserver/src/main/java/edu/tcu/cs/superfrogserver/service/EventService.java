package edu.tcu.cs.superfrogserver.service;



import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import edu.tcu.cs.superfrogserver.dao.EventDao;
import edu.tcu.cs.superfrogserver.domain.Event;
import edu.tcu.cs.superfrogserver.utils.IdWorker;

@Service
@Transactional
public class EventService {

    private EventDao dao;
    private IdWorker idWorker;



    //having a constructor allows spring to inject instance of dao into the class without using a "new" keyword
    public EventService(EventDao dao, IdWorker idWorker) {
        this.dao = dao;
        this.idWorker = idWorker;
    }



    public List<Event> findAll() {
        return null;
    }



    public void save(Event newevent) {
    }



    public Object findById(int eventId) {
        return null;
    }



    public void update(int eventId, Event updatedevent) {
    }

    
}
