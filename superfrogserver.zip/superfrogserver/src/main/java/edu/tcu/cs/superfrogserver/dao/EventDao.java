package edu.tcu.cs.superfrogserver.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.tcu.cs.superfrogserver.domain.Event;

public interface EventDao extends JpaRepository<Event, String>{
    
}
