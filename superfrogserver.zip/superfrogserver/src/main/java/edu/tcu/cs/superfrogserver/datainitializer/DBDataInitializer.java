package edu.tcu.cs.superfrogserver.datainitializer;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import edu.tcu.cs.superfrogserver.dao.EventDao;
import edu.tcu.cs.superfrogserver.domain.Event;

@Component
public class DBDataInitializer implements CommandLineRunner{

    private EventDao eventDao;
    



    public DBDataInitializer(EventDao eventDao) {
        this.eventDao = eventDao;
    }
    
    

    @Override
    public void run(String... args) throws Exception {
        Event e1 = new Event();
        e1.setEventId(1);
        e1.setName("exampleEventName");
        e1.setClientId(1);
        e1.setLocation("2800 S University Dr, Tx, 76129");
        e1.setDate("2022-05-05");
        e1.setDescription("A client's description of the event and what the superfrog will be doing");
        e1.setFrog("examplefrog");
        e1.setStatus("CONFIRMED");
        Event e2 = new Event();
        e2.setEventId(2);
        e2.setName("exampleEventName2");
        e2.setClientId(1);
        e2.setLocation("2800 S University Dr, Tx, 76129");
        e2.setDate("2022-05-06");
        e2.setDescription("A client's description of the event and what the superfrog will be doing");
        e2.setFrog("examplefrog2");
        e2.setStatus("PENDING");
        Event e3 = new Event();
        e3.setEventId(3);
        e3.setName("exampleEventName3");
        e3.setClientId(2);
        e3.setLocation("2800 S University Dr, Tx, 76129");
        e3.setDate("2022-05-07");
        e3.setDescription("A client's description of the event and what the superfrog will be doing");
        e3.setFrog("examplefrog1");
        e3.setStatus("REJECTED");
        
        eventDao.save(e1);
        eventDao.save(e2);
        eventDao.save(e3);
        
    }

    
}
