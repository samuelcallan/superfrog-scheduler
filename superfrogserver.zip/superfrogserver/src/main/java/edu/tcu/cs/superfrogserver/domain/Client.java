package edu.tcu.cs.superfrogserver.domain;

import java.io.Serializable;

import javax.persistence.*;


@Entity
public class Client implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer clientId;
    private String name;
    private String phone;
    private String email;
    private String password;
    private String role;
    private boolean isActive;

    public Client(){
    }
    


    public Integer getClientId() {
        return this.clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return this.phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return this.role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public boolean isIsActive() {
        return this.isActive;
    }

    public boolean getIsActive() {
        return this.isActive;
    }

    public void setIsActive(boolean isActive) {
        this.isActive = isActive;
    }

    


    
    
}
