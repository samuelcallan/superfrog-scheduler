package edu.tcu.cs.superfrogserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import edu.tcu.cs.superfrogserver.utils.IdWorker;

@SpringBootApplication
public class SuperfrogserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(SuperfrogserverApplication.class, args);
	}

	@Bean
	public IdWorker idWorker(){
		return new IdWorker(1, 1);
	}

}
